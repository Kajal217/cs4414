#include "life.h"
#include <pthread.h>

void simulate_life_parallel(int threads, LifeBoard &state, int steps) {
    /* YOUR CODE HERE */
}
