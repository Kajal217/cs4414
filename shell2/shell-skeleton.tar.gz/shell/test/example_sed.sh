#!/bin/sh
sed -e 's/bar/XXX/'
