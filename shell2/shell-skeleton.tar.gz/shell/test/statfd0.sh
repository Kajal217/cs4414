#!/bin/sh
/usr/bin/stat -L -c %F /proc/self/fd/0
